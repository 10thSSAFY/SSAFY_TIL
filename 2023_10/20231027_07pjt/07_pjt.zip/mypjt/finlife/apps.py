from django.apps import AppConfig


class FinlifeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'finlife'
