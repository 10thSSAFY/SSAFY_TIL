from django.shortcuts import render
from django.conf import settings
from rest_framework.decorators import api_view
from rest_framework.response import Response
import requests
from .models import DepositOptions, DepositProducts
from .serializer import DepositOptionsSerializer, DepositProductsSerializer
# Create your views here.
@api_view(['GET'])
def save_deposit_products(request):
    api_key = settings.API_KEY
    print(api_key)
    url = f'http://finlife.fss.or.kr/finlifeapi/depositProductsSearch.json?auth={api_key}&topFinGrpNo=020000&pageNo=1'

    response = requests.get(url).json()
    # print(response)
    for li in response.get("result").get("baseList"):
        save_baselist = {
            'fin_prdt_cd': li.get('fin_prdt_cd'),
            'kor_co_nm': li.get('kor_co_nm'),
            'fin_prdt_nm': li.get('fin_prdt_nm'),
            'etc_note': li.get('etc_note'),
            'join_deny': li.get('join_deny'),
            'join_member': li.get('join_member'),
            'join_way': li.get('join_way'),
            'spcl_cnd': li.get('spcl_cnd'),
        }

        if DepositProducts.objects.filter(fin_prdt_cd=li.get('fin_prdt_cd')).exists():
            continue

        serializer = DepositProductsSerializer(data = save_baselist)
        if serializer.is_valid(raise_exception=True):
            serializer.save()

    for li in response.get("result").get("optionList"):
        save_optionlist = {
            'fin_prdt_cd': li.get('fin_prdt_cd'),
            'intr_rate_type_nm': li.get('intr_rate_type_nm'),
            'intr_rate': li.get('intr_rate'),
            'intr_rate2': li.get('intr_rate2'),
            'save_trm': li.get('save_trm'),
        }
        serializer = DepositOptionsSerializer(data = save_optionlist)
        product = DepositProducts.objects.get(fin_prdt_cd=save_optionlist['fin_prdt_cd'])

        if not DepositOptions.objects.filter(fin_prdt_cd=save_optionlist['fin_prdt_cd'], intr_rate_type_nm=save_optionlist['intr_rate_type_nm'],
                                                 intr_rate=save_optionlist['intr_rate'], intr_rate2=save_optionlist['intr_rate2'], save_trm=save_optionlist['save_trm']).exists():  
            if serializer.is_valid(raise_exception=True):
                serializer.save(product=product)
           
    return Response({'message': 'okay'})

@api_view(['GET', 'POST'])
def deposit_products(request):
    if request.method == 'GET':
        baselist_products = DepositProducts.objects.all()
        serializer = DepositProductsSerializer(baselist_products, many=True)
        return Response(serializer.data)
    elif request.method == 'POST':
        serializer = DepositProductsSerializer(data = request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data)


@api_view(['GET'])
def deposit_product_options(request, fin_prdt_cd):
    products = DepositOptions.objects.filter(fin_prdt_cd=fin_prdt_cd)
    serializer = DepositOptionsSerializer(products, many=True)
    return Response(serializer.data)


from django.db.models import Max
@api_view(['GET'])
def top_rate(request):
    option = DepositOptions.objects.order_by('-intr_rate2').first()
    product = option.product
    options = DepositOptions.objects.filter(product=product)
    result = {
        'deposit_product': DepositProductsSerializer(product).data,
        'options': DepositOptionsSerializer(options, many=True).data,
    }

    return Response(result)
    
    
