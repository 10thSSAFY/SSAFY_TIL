<template>
  <div>
    <h3>Article List</h3>
    <ArticleListItem />
  </div>
</template>

<script setup>
import ArticleListItem from '@/components/ArticleListItem.vue'
</script>
